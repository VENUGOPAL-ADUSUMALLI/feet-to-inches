a=float(input())
print(a*12)